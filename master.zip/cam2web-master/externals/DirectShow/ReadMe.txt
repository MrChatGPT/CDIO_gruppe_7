The folder contains "qedit.h" file to make MSVC happy when building DirectShow related project.
The file is no longer part of Windows SDK, so needs to be obtained from other sources (like older
DirectX SDK).

The file come from the link below:
http://social.msdn.microsoft.com/Forums/en-US/windowsdirectshowdevelopment/thread/2ab5c212-5824-419d-b5d9-7f5db82f57cd
